-- SquadVault database schema
create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  username text,
  avatar_url text,
  role text not null default 'user' check (role in ('user','partner','admin')),
  rating numeric(2,1) default 0,
  review_count integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.listings (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text,
  game text not null default 'Gaming',
  price_inr integer not null check (price_inr >= 0),
  platform_fee_inr integer not null default 450 check (platform_fee_inr = 450),
  status text not null default 'pending' check (status in ('pending','approved','reserved','sold','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.listing_images (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.listings(id) on delete cascade,
  storage_path text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid references public.listings(id) on delete set null,
  reviewer_id uuid not null references public.profiles(id) on delete cascade,
  seller_id uuid not null references public.profiles(id) on delete cascade,
  rating integer not null check (rating between 1 and 5),
  comment text,
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid references public.listings(id) on delete cascade,
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  reason text not null,
  status text not null default 'open' check (status in ('open','reviewing','resolved','dismissed')),
  resolved_by uuid references public.profiles(id),
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into public.profiles(id,email,username) values(new.id,new.email,coalesce(new.raw_user_meta_data->>'username',split_part(new.email,'@',1)));
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

alter table public.profiles enable row level security;
alter table public.listings enable row level security;
alter table public.listing_images enable row level security;
alter table public.reviews enable row level security;
alter table public.reports enable row level security;

create policy "approved listings are public" on public.listings for select using (status='approved' or auth.uid()=seller_id);
create policy "users create own listings" on public.listings for insert with check (auth.uid()=seller_id);
create policy "users update own pending listings" on public.listings for update using (auth.uid()=seller_id and status='pending') with check (auth.uid()=seller_id);

create policy "profiles are readable" on public.profiles for select using (true);
create policy "users update own profile" on public.profiles for update using (auth.uid()=id);

create policy "listing images for visible listings" on public.listing_images for select using (
  exists(select 1 from public.listings l where l.id=listing_id and (l.status='approved' or l.seller_id=auth.uid()))
);
create policy "owners add listing images" on public.listing_images for insert with check (
  exists(select 1 from public.listings l where l.id=listing_id and l.seller_id=auth.uid())
);

create policy "reviews readable" on public.reviews for select using (true);
create policy "authenticated users review" on public.reviews for insert with check (auth.uid()=reviewer_id);

-- IMPORTANT:
-- Admin/partner moderation should be implemented with secure server-side checks or
-- carefully scoped RLS policies based on a trusted role claim. Never trust a client-side role field.
-- Do not store game passwords/recovery codes.
