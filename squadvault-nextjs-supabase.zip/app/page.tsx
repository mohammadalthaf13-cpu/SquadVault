import { createClient } from "@/utils/supabase/server";
import Marketplace from "./marketplace";

export default async function Page() {
  const supabase = await createClient();
  const { data: listings } = await supabase
    .from("listings")
    .select("id,title,description,game,price_inr,platform_fee_inr,status,seller_id,created_at")
    .eq("status", "approved")
    .order("created_at", { ascending: false });

  return <Marketplace initialListings={listings ?? []} />;
}