 "use client";
import { useMemo, useState } from "react";
import { createClient } from "@/utils/supabase/client";

type Listing = {
  id:string; title:string; description:string|null; game:string;
  price_inr:number; platform_fee_inr:number; status:string; seller_id:string; created_at:string;
};

export default function Marketplace({initialListings}:{initialListings:Listing[]}) {
  const [q,setQ]=useState(""); const [show,setShow]=useState<"login"|"signup"|null>(null);
  const [email,setEmail]=useState(""); const [password,setPassword]=useState(""); const [message,setMessage]=useState("");
  const filtered=useMemo(()=>initialListings.filter(x=>(x.title+" "+(x.description||"")).toLowerCase().includes(q.toLowerCase())),[initialListings,q]);

  async function auth(mode:"login"|"signup"){
    const supabase=createClient();
    const result=mode==="login"
      ? await supabase.auth.signInWithPassword({email,password})
      : await supabase.auth.signUp({email,password});
    setMessage(result.error?.message ?? (mode==="signup"?"Account created. Check your email if confirmation is enabled.":"Logged in."));
  }

  function whatsapp(x:Listing){
    const n=process.env.NEXT_PUBLIC_ADMIN_WHATSAPP || "";
    const text=encodeURIComponent(`Hello SquadVault Admin, I'm interested in "${x.title}". Listing price: ₹${x.price_inr}. Please guide me through the supported transaction process.`);
    if(n) window.open(`https://wa.me/${n}?text=${text}`,"_blank"); else setMessage("Add NEXT_PUBLIC_ADMIN_WHATSAPP to .env.local first.");
  }

  return <main>
    <header className="nav"><div className="logo">SQUAD<span>VAULT</span></div>
      <div><button onClick={()=>setShow("login")}>Log in</button><button className="primary" onClick={()=>setShow("signup")}>Sign up</button></div>
    </header>
    <section className="hero"><div className="ey">FOOTBALL GAMING MARKETPLACE</div>
      <h1>Discover squads.<br/><span>Compare details.</span></h1>
      <p>Community listings, seller information and admin-supervised support. Payment discussions are handled directly with authorized admins through WhatsApp.</p>
      <div className="search"><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search listings..."/><button className="primary" onClick={()=>setShow("signup")}>Create account</button></div>
    </section>
    <section className="wrap"><div className="sectionHead"><div><h2>Marketplace</h2><p>Admin-approved listings</p></div><div className="fee">₹450 platform fee</div></div>
      <div className="grid">{filtered.map(x=><article className="card" key={x.id}><div className="pic">⚽</div><div className="body">
        <div className="badge">✓ VERIFIED / APPROVED</div><h3>{x.title}</h3><p className="muted">{x.description||"No description provided."}</p>
        <p className="muted">{x.game} · Seller ID {x.seller_id.slice(0,8)}…</p>
        <div className="row"><strong>₹{x.price_inr.toLocaleString("en-IN")}</strong><button onClick={()=>whatsapp(x)} className="primary">Contact Admin</button></div>
      </div></article>)}</div>
      {!filtered.length && <div className="empty">No approved listings found.</div>}
      <div className="admin"><h2>Admin-supervised support</h2><p>Listings can be submitted for review. The website does not collect payment details. Admins can coordinate supported transactions through WhatsApp.</p><b>Fixed platform / middleman fee: ₹450</b></div>
    </section>
    <footer>© 2026 SquadVault · Do not upload passwords or recovery credentials.</footer>

    {show && <div className="modal"><div className="box"><button className="close" onClick={()=>setShow(null)}>×</button>
      <h2>{show==="login"?"Log in":"Create account"}</h2><input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email address"/>
      <input value={password} onChange={e=>setPassword(e.target.value)} type="password" placeholder="Password"/>
      <button className="primary wide" onClick={()=>auth(show)}>{show==="login"?"Log in":"Sign up"}</button>
      {message&&<p className="notice">{message}</p>}
    </div></div>}
  </main>;
}