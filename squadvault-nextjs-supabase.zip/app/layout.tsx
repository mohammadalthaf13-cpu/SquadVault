import "./globals.css";

export const metadata = {
  title: "SquadVault | Football Gaming Marketplace",
  description: "Admin-supervised football gaming marketplace."
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}